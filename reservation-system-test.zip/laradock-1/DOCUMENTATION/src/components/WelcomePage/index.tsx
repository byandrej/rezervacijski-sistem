import React from 'react';
import styles from './styles.module.css';

export default function WelcomePage() {
  return (
    <section className={styles.welcome}>
      <h1>Fully Dockerized PHP Environment, Ready to Go!</h1>
    </section>
  );
}
