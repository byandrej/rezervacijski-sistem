<?php $__env->startComponent('mail::message'); ?>
<h2>Prejeli ste novo rezervacijo</h2>
<ul>
    <li>Ime: <?php echo e($data['ime']); ?></li>
    <li>Email: <?php echo e($data['email']); ?></li>
    <li>Telefon: <?php echo e($data['telefon']); ?></li>
    <li>Sporocilo: <?php echo e($data['sporocilo']); ?></li>
    <li>Soba: <?php echo e($data->room->ime); ?></li>
    <li>Cena: <?php echo e($data['skupna_cena']); ?> €</li>
</ul>
<br>
<p>
    To je samodejno sporočilo. Prosimo ne odpisujte.
</p><br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\reservation-system-test\resources\views/emails/contactus/admin.blade.php ENDPATH**/ ?>