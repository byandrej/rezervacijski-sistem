<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Admin Dashboard</h1>

    <h2>Sobe (Rooms)</h2>
    <a href="<?php echo e(route('admin.rooms.create')); ?>" class="btn btn-primary mb-3">Dodaj novo sobo</a>
    <table class="table">
        <thead>
            <tr>
                <th>Ime</th>
                <th>Cena</th>
                <th>Dejavnost</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($room->ime); ?></td>
                <td><?php echo e($room->cena); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.rooms.edit', $room->id)); ?>" class="btn btn-warning">Uredi</a>
                    <form action="<?php echo e(route('admin.rooms.destroy', $room->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger">Izbriši</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h2>Rezervacije</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Ime</th>
                <th>Soba</th>
                <th>Datum</th>
                <th>Cena</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($reservation->ime); ?></td>
                <td><?php echo e($reservation->room->ime); ?></td>
                <td><?php echo e($reservation->prihod); ?> - <?php echo e($reservation->odhod); ?></td>
                <td><?php echo e($reservation->skupna_cena); ?> €</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($reservations->links()); ?>

    <p class="mt-3">
        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="btn btn-secondary">Odjava</a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </p>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reservation-system-test\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>