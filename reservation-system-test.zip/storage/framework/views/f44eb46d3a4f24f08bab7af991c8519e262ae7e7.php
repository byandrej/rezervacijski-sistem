<?php $__env->startSection('title', 'Edit Room'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1 class="mb-4">Uredi Sobo <?php echo e($room->ime); ?></h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.rooms.update', $room->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="name" class="form-label">Room Name</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('ime', $room->ime)); ?>" placeholder="<?php echo e($room->ime); ?>" required>
        </div>

        <div class="mb-3">
            <label for="price" class="form-label">Price per Night (€)</label>
            <input type="number" name="price" id="price" class="form-control" value="<?php echo e(old('cena', $room->cena)); ?>" required step="0.01" min="0">
        </div>

        <div class="mb-3">
            <label for="short_description" class="form-label">Short Description</label>
            <textarea name="short_description" id="short_description" class="form-control" rows="2" required><?php echo e(old('kratek_opis', $room->kratek_opis)); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="long_description" class="form-label">Long Description</label>
            <textarea name="long_description" id="long_description" class="form-control" rows="5" required><?php echo e(old('dolg_opis', $room->dolg_opis)); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Update Room</button>
        <a href="<?php echo e(route('admin.rooms.index')); ?>" class="btn btn-secondary">Back to List</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\reservation-system-test\resources\views/admin/rooms/edit.blade.php ENDPATH**/ ?>