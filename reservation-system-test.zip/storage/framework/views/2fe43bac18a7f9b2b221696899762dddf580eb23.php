<?php $__env->startComponent('mail::message'); ?>
<p>Hvala za oddano povpraševanje</p>
<p>Uspešno ste rezervirali sobo <?php echo e($data->room->ime); ?></p>
<p>Od: <?php echo e($data['prihod']); ?> do: <?php echo e($data->odhod); ?></p>
<p>Cena: <?php echo e($data->skupna_cena); ?></p>
<br>
<p>
    To je samodejno sporočilo. Prosimo ne odpisujte.
</p><br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\reservation-system-test\resources\views/emails/contactus/zahvala.blade.php ENDPATH**/ ?>