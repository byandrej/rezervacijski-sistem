<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?php echo e(URL::asset('favicon.ico')); ?>" type="image/gif" sizes="16x16" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php if(isset($title)): ?><?php echo e($title); ?><?php else: ?> <?php echo e(__('Rezervacija')); ?> <?php endif; ?> | <?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Scripts -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
    <?php echo RecaptchaV3::initJs(); ?>

    <link href="<?php echo e(mix('css/app_custom.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('app-css'); ?>
</head>

<body>
    <nav class="navbar navbar-expand-md navbar-dark">
    </nav>

    <main class="">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="footer">
        <div class="footer-1">
            <span>Andrej Marsetič | 2024</span>
        </div>

    </footer>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\reservation-system-test\resources\views/layouts/app.blade.php ENDPATH**/ ?>